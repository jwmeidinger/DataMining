
## Author: Jordan Meidinger
## Assignment: 5 Networking Graph
## Source: https://gist.github.com/TefiC/c20fb765ad2c85008f3d05a300bf26ed#file-adjacencymatrix-py

import numpy as np
import matplotlib.pyplot as plt

filename = "karate.txt" ## input new files Here
X = np.loadtxt(filename)
n = max(max(X[:,0]),max(X[:,1])) ## Max node

## Used to create Matrix
class Graph(object): 
	def __init__(self, numNodes):
		self.adjacencyMatrix = [] #Blank 2D list
		for i in range(numNodes): 
			self.adjacencyMatrix.append([0 for i in range(numNodes)])
		self.numNodes = numNodes

	def addEdge(self, start, end):
		self.adjacencyMatrix[start][end] = 1

## Used to get the degrees of each node
def degrees(g):  
     result = 0
     distrubtion = []
     for i in range(g.numNodes):
          for x in range(len(g.adjacencyMatrix[i])):
               if g.adjacencyMatrix[i][x] == 1:
                    result += 1
          distrubtion.append(result)
          result = 0
     return distrubtion

# Cluster Co
def clusterCo(g):
     result = 0
     distrubtion = []
     items = []
     final = []
     for i in range(len(g.adjacencyMatrix)):
          for x in range(len(g.adjacencyMatrix[i])): ## go row by row
               if g.adjacencyMatrix[i][x] == 1: ## if colum has a 1 put that into the items
                    items.append(x) 
               zero = np.sum(g.adjacencyMatrix[i]) 
               if zero == 0:
                    items.append(0) 
                    break
          for item in items:
               z = np.sum(g.adjacencyMatrix[item]) ## get sum of the rows
               result = result + z
          distrubtion.append(result) ## put result of each row of how many degrees there are accumulative 
          result = 0
          items = []

     for y in range(len(distrubtion)): ## finding the average Clustering Coefficient
          n = (distrubtion[y]/2)
          d = degrees(g)
          s = d[y]
          if s <= 2:
               final.append(0)
          else:
               final.append(n/s*(s-1))

     p = np.sum(final)
     return (p/len(distrubtion))


g = Graph(int(n)+1) ## needs plus one due to python starting at 0

# add points to the Matrix
for i in range(len(X)):
     g.addEdge(int(X[i][0]),int(X[i][1]))

d = degrees(g=g)

## Plot J K
for i in range(len(d)):
     if i != 0:
          j = i
          k = d[i]
          plt.scatter(j,k)

plt.show() 

# Plot j, P(J)
for i in range(len(d)):
     if i != 0:
          j = i
          k = (d[i]/g.numNodes) 
          if k != 0:
               plt.scatter(np.log2(j),k)

plt.show() 

     
c = clusterCo(g)

print (c)
