## Author: Jordan Meidinger
## Assignment 4 Data Mining 11/2/2019 - K Means Cluster Algo
## Source: https://pythonprogramming.net/k-means-from-scratch-machine-learning-tutorial/

import matplotlib.pyplot as plt
import random
from matplotlib import style
style.use('ggplot')
import numpy as np

colors = 10*["g","r","c","b","k","m","y"]

## Algo
class K_Means:
    def __init__(self, k=4, tol=0.001, max_iter=20):
        self.k = k ## Number of clusters
        self.tol = tol ## Tolerence allowed
        self.max_iter = max_iter ## Max number of times for new iteration as more points are added

    def fit(self,data):
        self.iterations = 0
        self.centroids = {}

        for i in range(self.k):
            self.centroids[i] = data[i] ## first to data points for the first centerpoints

        for i in range(self.max_iter):
            self.iterations += 1
            self.classifications = {}

            for i in range(self.k):
                self.classifications[i] = [] ## Define how many clusters there are and to seperate them

            for featureset in data:
                distances = [np.linalg.norm(featureset-self.centroids[centroid]) for centroid in self.centroids] ## Find distance to point
                classification = distances.index(min(distances)) ## Define the classification for the point
                self.classifications[classification].append(featureset)

            prev_centroids = dict(self.centroids)

            for classification in self.classifications: 
                self.centroids[classification] = np.average(self.classifications[classification],axis=0)

            optimized = True

            for c in self.centroids: ## take all of the centroids and compare them to the previous centroids to make sure we get the best one
                original_centroid = prev_centroids[c]
                current_centroid = self.centroids[c]
                if np.sum((current_centroid-original_centroid)/original_centroid*100.0) > self.tol:
                    #print(np.sum((current_centroid-original_centroid)/original_centroid*100.0))
                    optimized = False
                else:
                    self.belowHold = np.sum((current_centroid-original_centroid)/original_centroid*100.0)
            if optimized:
                break

#################################################################################################

XData = np.loadtxt('fourCircles.txt')
plt.scatter(XData[:,0], XData[:,1], s=50)
#plt.show() ## Uncomment to see the preview

## Set up
clf = K_Means(k=4)
clf.fit(XData)
stringclass = "fourCircles "
classNum = 0

for classification in clf.classifications: ## Mark items for graph with color
    color = colors[classification]
    for featureset in clf.classifications[classification]:
        plt.scatter(featureset[0], featureset[1], marker="o", color=color, s=150, linewidths=5)

for centroid in clf.centroids: ## Mark centroid
    x = clf.centroids[centroid][0]
    y = clf.centroids[centroid][1]
    print (("fourCircles Point: {} X: {} Y: {}").format(classNum,x,y)) ## Also Print in console
    plt.scatter(x, y, marker="o", color="k", s=150, linewidths=5)  
    classNum += 1

for classification in clf.classifications: ## Print out Size of each cluster
        print(("fourCircles Class: {} Number of points: {}").format(classification, len(clf.classifications[classification])))

for item in XData: ## Creates a String with Final cluster
    for classification in clf.classifications:
        for featureset in clf.classifications[classification]:
            if list(item) == list(featureset):
                stringclass =  (stringclass + "{} ").format(classification)

print(stringclass)
print(("fourCircles δ: {}  Iterations: {}").format(clf.belowHold, clf.iterations))                    
plt.show() ## fourCircles with Color

#################################################################################################

XData = np.loadtxt('twoCircles.txt')
plt.scatter(XData[:,0], XData[:,1], s=50)
#plt.show() ## Uncomment to see the preview

## Set up
clf = K_Means(k=2)
clf.fit(XData)
stringclass = "twoCircles "
classNum = 0

for classification in clf.classifications: ## Mark items for graph with color
    color = colors[classification]
    for featureset in clf.classifications[classification]:
        plt.scatter(featureset[0], featureset[1], marker="o", color=color, s=150, linewidths=5)

for centroid in clf.centroids: ## Mark centroid
    x = clf.centroids[centroid][0]
    y = clf.centroids[centroid][1]
    print (("twoCircles Point: {} X: {} Y: {}").format(classNum,x,y)) ## Also Print in console
    plt.scatter(x, y, marker="o", color="k", s=150, linewidths=5)  
    classNum += 1

for classification in clf.classifications: ## Print out Size of each cluster
        print(("twoCircles Class: {} Number of points: {}").format(classification, len(clf.classifications[classification])))

for item in XData: ## Creates a String with Final cluster
    for classification in clf.classifications:
        for featureset in clf.classifications[classification]:
            if list(item) == list(featureset):
                stringclass =  (stringclass + "{} ").format(classification)

print(stringclass)
print(("twoCircles δ: {}  Iterations: {}").format(clf.belowHold, clf.iterations))                    
plt.show() ## twoCircles with Color

#################################################################################################

XData = np.loadtxt('twoEllipses.txt')
plt.scatter(XData[:,0], XData[:,1], s=50)
#plt.show() ## Uncomment to see the preview


## Set up
clf = K_Means(k=2)
clf.fit(XData)
stringclass = "twoEllipses "
classNum = 0

for classification in clf.classifications: ## Mark items for graph with color
    color = colors[classification]
    for featureset in clf.classifications[classification]:
        plt.scatter(featureset[0], featureset[1], marker="o", color=color, s=150, linewidths=5)

for centroid in clf.centroids: ## Mark centroid
    x = clf.centroids[centroid][0]
    y = clf.centroids[centroid][1]
    print (("twoEllipses Point: {} X: {} Y: {}").format(classNum,x,y)) ## Also Print in console
    plt.scatter(x, y, marker="o", color="k", s=150, linewidths=5)  
    classNum += 1

for classification in clf.classifications: ## Print out Size of each cluster
        print(("twoEllipses Class: {} Number of points: {}").format(classification, len(clf.classifications[classification])))

for item in XData: ## Creates a String with Final cluster
    for classification in clf.classifications:
        for featureset in clf.classifications[classification]:
            if list(item) == list(featureset):
                stringclass =  (stringclass + "{} ").format(classification)

print(stringclass)
print(("twoEllipses δ: {}  Iterations: {}").format(clf.belowHold, clf.iterations))                    
plt.show() ## twoEllipses with Color

#################################################################################################

XData = np.loadtxt('iris.txt')
plt.scatter(XData[:,0], XData[:,1], s=50)
#plt.show() ## Uncomment to see the preview

## Set up
clf = K_Means(k=3)
clf.fit(XData)
stringclass = "Iris "
classNum = 0

for classification in clf.classifications: ## Mark items for graph with color
    color = colors[classification]
    for featureset in clf.classifications[classification]:
        plt.scatter(featureset[0], featureset[1], marker="o", color=color, s=150, linewidths=5)

for centroid in clf.centroids: ## Mark centroid
    x = clf.centroids[centroid][0]
    y = clf.centroids[centroid][1]
    print (("Iris Point: {} X: {} Y: {}").format(classNum,x,y)) ## Also Print in console
    plt.scatter(x, y, marker="o", color="k", s=150, linewidths=5)  
    classNum += 1

for classification in clf.classifications: ## Print out Size of each cluster
        print(("Iris Class: {} Number of points: {}").format(classification, len(clf.classifications[classification])))

for item in XData: ## Creates a String with Final cluster
    for classification in clf.classifications:
        for featureset in clf.classifications[classification]:
            if list(item) == list(featureset):
                stringclass =  (stringclass + "{} ").format(classification)

print(stringclass)
print(("Iris δ: {}  Iterations: {}").format(clf.belowHold, clf.iterations))                    
plt.show() ## Iris Circles with Colors This one looks weird becuase I only plot two points


#################################################################################################

XData = np.loadtxt('t4.8k.txt')
plt.scatter(XData[:,0], XData[:,1], s=50)
#plt.show() ## Uncomment to see the preview

## Set up
clf = K_Means(k=6)
clf.fit(XData)
stringclass = "t4.8k "
classNum = 0

for classification in clf.classifications: ## Mark items for graph with color
    color = colors[classification]
    for featureset in clf.classifications[classification]:
        plt.scatter(featureset[0], featureset[1], marker="o", color=color, s=150, linewidths=5)

for centroid in clf.centroids: ## Mark centroid
    x = clf.centroids[centroid][0]
    y = clf.centroids[centroid][1]
    print (("t4.8k Point: {} X: {} Y: {}").format(classNum,x,y)) ## Also Print in console
    plt.scatter(x, y, marker="o", color="k", s=150, linewidths=5)  
    classNum += 1

for classification in clf.classifications: ## Print out Size of each cluster
        print(("t4.8k Class: {} Number of points: {}").format(classification, len(clf.classifications[classification])))

for item in XData: ## Creates a String with Final cluster
    for classification in clf.classifications:
        for featureset in clf.classifications[classification]:
            if list(item) == list(featureset):
                stringclass =  (stringclass + "{} ").format(classification)

print(stringclass)
print(("t4.8k δ: {}  Iterations: {}").format(clf.belowHold, clf.iterations))                    
plt.show() ## t4.8k with Color