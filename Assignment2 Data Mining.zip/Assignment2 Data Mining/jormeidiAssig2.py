
## Purpose: Created k near Neighbors from scratch using euclidean distance 
## Date: 10/9/2019 
## Python Version: 3.7.3
## Author: Jordan Meidinger 

import math, operator, random, time, warnings
import numpy as np

from collections import Counter
from prettytable import PrettyTable

def euclideanDistance(instance1, instance2, length):
	distance = 0
	for x in range(length):
		distance += pow((instance1[x] - instance2[x]), 2)
	return math.sqrt(distance)

def getNeighbors(trainingSet, testInstance, k):
	distances = []
	length = len(testInstance)-1
	for x in range(len(trainingSet)):
		dist = euclideanDistance(testInstance, trainingSet[x], length)
		distances.append((trainingSet[x], dist))
	distances.sort(key=operator.itemgetter(1))
	neighbors = []
	for x in range(k):
		neighbors.append(distances[x][0])
	return neighbors

def getResponse(neighbors):
	classVotes = {}
	for x in range(len(neighbors)):
		response = neighbors[x][-1]
		if response in classVotes:
			classVotes[response] += 1
		else:
			classVotes[response] = 1
	sortedVotes = sorted(classVotes.items(), key=operator.itemgetter(1), reverse=True)
	return sortedVotes[0][0]

def getAccuracy(testSet, predictions):
	correct = 0
	for x in range(len(testSet)):
		if testSet[x][-1] == predictions[x]:
			correct += 1
	return (correct/float(len(testSet))) * 100.0

trainingFile = "irisTraining.txt"
testingFile = "irisTesting.txt"
Xtrain = np.loadtxt(trainingFile)
Xtest = np.loadtxt(testingFile)

#Testing irisTraining.....
#Create table
t = PrettyTable(['Experiment', 'Accuracy','Sensitivity', 'Specificty' ,'Precision'])

tp = 0 #True Positive
fp = 0 #False Positive
tn = 0 #True Negative
fn = 0 #False Negative

k = 5
for x in range(len(Xtest)):
  neighbors = getNeighbors(Xtrain, Xtest[x], k)
  result = getResponse(neighbors)
  actual = Xtest[x][-1]
  if result == 1.0 and actual == 1.0:
    tp += 1
  elif result == 1.0 and actual == -1.0:
    fp += 1
  elif result == -1.0 and actual == -1.0:
    tn += 1
  elif result == -1.0 and actual == 1.0:
    fn += 1
  else:
    warnings.warn("something went wrong!")

t.add_row(['irisTraining K=05', ((tp + tn)/(tp+fp+tn+fn)) , ((tp)/(tp+fn)) , ((tn)/(fp+tn)), ((tp)/(tp+fp))])
tp = 0 #True Positive
fp = 0 #False Positive
tn = 0 #True Negative
fn = 0 #False Negative

k = 11
for x in range(len(Xtest)):
  neighbors = getNeighbors(Xtrain, Xtest[x], k)
  result = getResponse(neighbors)
  actual = Xtest[x][-1]
  if result == 1.0 and actual == 1.0:
    tp += 1
  elif result == 1.0 and actual == -1.0:
    fp += 1
  elif result == -1.0 and actual == -1.0:
    tn += 1
  elif result == -1.0 and actual == 1.0:
    fn += 1
  else:
    warnings.warn("something went wrong!")

t.add_row(['irisTraining K=11', ((tp + tn)/(tp+fp+tn+fn)) , ((tp)/(tp+fn)) , ((tn)/(fp+tn)), ((tp)/(tp+fp))])
tp = 0 #True Positive
fp = 0 #False Positive
tn = 0 #True Negative
fn = 0 #False Negative

k = 21
for x in range(len(Xtest)):
  neighbors = getNeighbors(Xtrain, Xtest[x], k)
  result = getResponse(neighbors)
  actual = Xtest[x][-1]
  if result == 1.0 and actual == 1.0:
    tp += 1
  elif result == 1.0 and actual == -1.0:
    fp += 1
  elif result == -1.0 and actual == -1.0:
    tn += 1
  elif result == -1.0 and actual == 1.0:
    fn += 1
  else:
    warnings.warn("something went wrong!")

t.add_row(['irisTraining K=21', ((tp + tn)/(tp+fp+tn+fn)) , ((tp)/(tp+fn)) , ((tn)/(fp+tn)), ((tp)/(tp+fp))])

#Loading new files 
trainingFile = "irisPCTraining.txt"
testingFile = "irisPCTesting.txt"
Xtrain = np.loadtxt(trainingFile)
Xtest = np.loadtxt(testingFile)

#Testing irisTraining.....

tp = 0 #True Positive
fp = 0 #False Positive
tn = 0 #True Negative
fn = 0 #False Negative

k = 5
for x in range(len(Xtest)):
  neighbors = getNeighbors(Xtrain, Xtest[x], k)
  result = getResponse(neighbors)
  actual = Xtest[x][-1]
  if result == 1.0 and actual == 1.0:
    tp += 1
  elif result == 1.0 and actual == -1.0:
    fp += 1
  elif result == -1.0 and actual == -1.0:
    tn += 1
  elif result == -1.0 and actual == 1.0:
    fn += 1
  else:
    warnings.warn("something went wrong!")

t.add_row(['irisPCTraining K=05', ((tp + tn)/(tp+fp+tn+fn)) , ((tp)/(tp+fn)) , ((tn)/(fp+tn)), ((tp)/(tp+fp))])

tp = 0 #True Positive
fp = 0 #False Positive
tn = 0 #True Negative
fn = 0 #False Negative

k = 11
for x in range(len(Xtest)):
  neighbors = getNeighbors(Xtrain, Xtest[x], k)
  result = getResponse(neighbors)
  actual = Xtest[x][-1]
  if result == 1.0 and actual == 1.0:
    tp += 1
  elif result == 1.0 and actual == -1.0:
    fp += 1
  elif result == -1.0 and actual == -1.0:
    tn += 1
  elif result == -1.0 and actual == 1.0:
    fn += 1
  else:
    warnings.warn("something went wrong!")

t.add_row(['irisPCTraining K=11', ((tp + tn)/(tp+fp+tn+fn)) , ((tp)/(tp+fn)) , ((tn)/(fp+tn)), ((tp)/(tp+fp))])

tp = 0 #True Positive
fp = 0 #False Positive
tn = 0 #True Negative
fn = 0 #False Negative

k = 21
for x in range(len(Xtest)):
  neighbors = getNeighbors(Xtrain, Xtest[x], k)
  result = getResponse(neighbors)
  actual = Xtest[x][-1]
  if result == 1.0 and actual == 1.0:
    tp += 1
  elif result == 1.0 and actual == -1.0:
    fp += 1
  elif result == -1.0 and actual == -1.0:
    tn += 1
  elif result == -1.0 and actual == 1.0:
    fn += 1
  else:
    warnings.warn("something went wrong!")

t.add_row(['irisPCTraining K=21', ((tp + tn)/(tp+fp+tn+fn)) , ((tp)/(tp+fn)) , ((tn)/(fp+tn)), ((tp)/(tp+fp))])

print(t)